<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MagicSuggest Tutorial</title>
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
  </head>
  <body>
    <div class="container">
        <h1>Hello, world!</h1>
        <form action="subscribe.php" method="post">
            <div class="form-group">
                <label>First name</label>
                <input class="form-control" name="firstname"/>
            </div>
            <div class="form-group">
                <label>Last name</label>
                <input class="form-control" name="lastname"/>
            </div>
            <input type="submit" class="btn btn-success pull-right" value="Submit"/>
        </form>
    </div>

    <script src="lib/jquery/jquery-1.11.1.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>