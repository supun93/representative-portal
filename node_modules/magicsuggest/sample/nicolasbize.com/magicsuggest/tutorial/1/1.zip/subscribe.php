<?php

$firstname = $_POST['firstname'] || '';
$lastname = $_POST['lastname'] || '';

$data = array('firstname' => $_POST['firstname'], 'lastname' => $_POST['lastname']);


?>
<html>
<head>
    <title></title>
</head>
<body>
    <p>

        Hello <?php echo $data['firstname']; ?> <?php echo $data['lastname'] ?>! <br/>

    </p>

</body>
</html>
